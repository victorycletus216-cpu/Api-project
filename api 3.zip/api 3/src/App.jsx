 import { BrowserRouter as Router,Routes,Route,Link,NavLink} from "react-router-dom"
 import Home from "./Home/Home"
 import Job from "./Job/Job"
 import "./App.css"
 const NotFound =()=>{
  return(
   <main className="not-found">
    <h1>Page not found</h1>
    <p>Sorry, the page you are looking for does not exist.</p>
    <Link to="/">Go back to the Home page</Link>
   </main>
  )
 }
 const App =()=> {
  return(
    <Router>
      <nav className="navbar">
        <span className="brand">API Practice</span>
        <div className="nav-links">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/Job">Jobs</NavLink>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home/>}></Route>
        <Route path="/Job" element={<Job/>}></Route>
        <Route path="*" element={<NotFound/>}></Route>
      </Routes>
    </Router>
  )
}
export default App;