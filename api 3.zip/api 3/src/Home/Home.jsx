import { useState,useEffect } from "react"
import "./Home.css"
const Home =()=>{
    const [thedata, setTheData] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState("")
    useEffect(()=>{
        const getStoreData =async()=>{
            try{
                const thedata =await fetch('https://dummyjson.com/products',
                {
                     method:"GET"
                }
                )
                const therealdata =await thedata.json();
                setTheData(therealdata.products || []);
            }catch{
                setError("Sorry, we could not load the products. Please try again later.")
            }
            setLoading(false)
        }
        getStoreData();
    },[])
    return(
        <main className="container">
             <h1 className="page-heading">My Homepage</h1>
             <p className="page-intro">Browse products fetched from the DummyJSON products API. Each card shows the product title, price and category.</p>
             {loading && <p className="message">Loading products...</p>}
             {error && <p className="message error">{error}</p>}
             {!loading && !error && thedata.length === 0 &&
                 <p className="message">No products found.</p>}
             <div className="product-grid">
             {thedata.map((each_value) => (
                <div className="card-container" key={each_value.id}>
                     <img src={each_value.thumbnail} alt={each_value.title}></img>
                     <div className="card-body">
                         <span className="card-category">{each_value.category}</span>
                         <h2 className="card-title">{each_value.title}</h2>
                         <p className="card-price">${each_value.price}</p>
                     </div>
                </div>
             ))}
             </div>
        </main>

    )
}
export default Home;
